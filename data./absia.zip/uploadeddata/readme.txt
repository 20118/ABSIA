######################################################################################

File "absia.csv" contain labelled data from multiple domains annotated for 7 classes. Corpus contains total 4650 tuples. Description of columns is as follows:

1) first column "id" represent Sequence number
2) Second column "aspects" represents aspect of review
3) Third columns "ordinal" represent the intensity for given aspect. 
4) Forth column "sentiment" represents sentiment of review for given aspect
3) Third columns "text" represent the review. 


High pos class is represented by '3'.
Mod pos class is represented by '2'.
Low pos class is represented by '1'.
Neutral class is represented by '0'.
Low neg class is represented by '-1'.
Mod neg class is represented by '-2'.
High neg class is represented by '-2'.

Statistics:

Total:4650

High pos: 384
Mod pos: 981
Low pos: 1478
Neutral: 817
Low neg: 682
Mod neg: 228
High neg: 80




######################################################################################



