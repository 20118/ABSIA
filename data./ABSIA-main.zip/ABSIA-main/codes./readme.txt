Dependencies:

Pytorch
pandas
simpletransformers
transformers
numpy

Place train, test and dev data in the "data" folder.
Run
1) For template creation
	python convert_toformat.py
2) To train joint model
	python train_joint_model.py
	
