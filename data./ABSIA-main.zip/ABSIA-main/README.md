# ABSIA
Aspect based sentiment intensity analysis

For requesting data, kindly fill the form avaiable at: https://www.iitp.ac.in/~ai-nlp-ml/resources.html#ABSIA

Dataset contain aspect terms and their corresponding polarities and sentiment intensities. Polarity can be positive, negative, neutral, or conflict and sentiment intensity can be high positive (3), moderate positive (2), low positive (1), neutral (0), low negative (-1), moderate negatve (-2), and high negative (-3).
